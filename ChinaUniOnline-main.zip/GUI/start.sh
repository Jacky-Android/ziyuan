#!/usr/bin/env sh
python main-gui.py || python main-gui.py
